<script type='text/javascript'>
    var _sf_async_config = _sf_async_config || {};
    /** CONFIGURATION START **/
    _sf_async_config.uid = 62058; //add the account number here!
    _sf_async_config.domain = 'bitchmedia.org'; //add the domain here (can be real or faux)
    _sf_async_config.useCanonical = true;
    _sf_async_config.flickerControl = false;
    var _sf_startpt = (new Date()).getTime();
    /** CONFIGURATION END **/
	</script>
 <script async src = "//static.chartbeat.com/js/chartbeat_mab.js"></script>